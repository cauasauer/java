var num1=738;
var num2=6829;

///console.log (num1+num2);

var soma
var resultado;

function calcularsoma(num1,num2) {
  soma = num1 + num2
  return soma;
}

resultado = calcularsoma(num1 , num2);
console.log('A soma é:',num1,'e',num2,'é' ,resultado)

num1=2000
num2=7

resultado = calcularsoma(num1,num2);
console.log('A soma é:',num1,'e',num2,'é' ,resultado)
